import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Edit, Trash2, Clock, Calendar as CalendarIcon } from "lucide-react";

interface Task {
  id: string;
  subject: string;
  priority: "high" | "medium" | "low";
  estimatedTime: number;
  dueDate: string;
  completed: boolean;
}

interface TaskListProps {
  tasks?: Task[];
  onTaskComplete?: (taskId: string) => void;
  onTaskEdit?: (task: Task) => void;
  onTaskDelete?: (taskId: string) => void;
}

const TaskList = ({
  tasks = [
    {
      id: "1",
      subject: "Mathematics",
      priority: "high" as const,
      estimatedTime: 120,
      dueDate: "2023-06-15",
      completed: false,
    },
    {
      id: "2",
      subject: "Physics",
      priority: "medium" as const,
      estimatedTime: 90,
      dueDate: "2023-06-18",
      completed: true,
    },
    {
      id: "3",
      subject: "Literature",
      priority: "low" as const,
      estimatedTime: 60,
      dueDate: "2023-06-20",
      completed: false,
    },
  ],
  onTaskComplete = () => {},
  onTaskEdit = () => {},
  onTaskDelete = () => {},
}: TaskListProps) => {
  const [filter, setFilter] = useState<string>("all");
  const [sortBy, setSortBy] = useState<string>("dueDate");
  const [searchTerm, setSearchTerm] = useState<string>("");

  // Group tasks by date
  const groupedTasks = tasks.reduce<Record<string, Task[]>>((acc, task) => {
    const date = task.dueDate;
    if (!acc[date]) {
      acc[date] = [];
    }
    acc[date].push(task);
    return acc;
  }, {});

  // Filter tasks
  const filteredDates = Object.keys(groupedTasks).filter((date) => {
    const tasksForDate = groupedTasks[date];
    return tasksForDate.some((task) => {
      const matchesSearch = task.subject
        .toLowerCase()
        .includes(searchTerm.toLowerCase());
      const matchesFilter =
        filter === "all" ||
        (filter === "completed" && task.completed) ||
        (filter === "pending" && !task.completed) ||
        filter === task.priority;
      return matchesSearch && matchesFilter;
    });
  });

  // Sort dates
  filteredDates.sort((a, b) => new Date(a).getTime() - new Date(b).getTime());

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "destructive";
      case "medium":
        return "secondary";
      case "low":
        return "outline";
      default:
        return "default";
    }
  };

  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  const formatTime = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `${hours > 0 ? `${hours}h ` : ""}${mins > 0 ? `${mins}m` : ""}`;
  };

  return (
    <Card className="w-full bg-white">
      <CardHeader className="pb-2">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <CardTitle>Tasks</CardTitle>
          <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
            <Input
              placeholder="Search tasks..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full sm:w-[200px]"
            />
            <div className="flex gap-2">
              <Select value={filter} onValueChange={setFilter}>
                <SelectTrigger className="w-[120px]">
                  <SelectValue placeholder="Filter" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="high">High Priority</SelectItem>
                  <SelectItem value="medium">Medium Priority</SelectItem>
                  <SelectItem value="low">Low Priority</SelectItem>
                </SelectContent>
              </Select>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-[120px]">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="dueDate">Due Date</SelectItem>
                  <SelectItem value="priority">Priority</SelectItem>
                  <SelectItem value="subject">Subject</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {filteredDates.length > 0 ? (
          filteredDates.map((date) => {
            const tasksForDate = groupedTasks[date].filter((task) => {
              const matchesSearch = task.subject
                .toLowerCase()
                .includes(searchTerm.toLowerCase());
              const matchesFilter =
                filter === "all" ||
                (filter === "completed" && task.completed) ||
                (filter === "pending" && !task.completed) ||
                filter === task.priority;
              return matchesSearch && matchesFilter;
            });

            // Sort tasks for this date
            if (sortBy === "priority") {
              const priorityOrder = { high: 0, medium: 1, low: 2 };
              tasksForDate.sort(
                (a, b) => priorityOrder[a.priority] - priorityOrder[b.priority],
              );
            } else if (sortBy === "subject") {
              tasksForDate.sort((a, b) => a.subject.localeCompare(b.subject));
            }

            if (tasksForDate.length === 0) return null;

            return (
              <div key={date} className="mb-6">
                <div className="flex items-center gap-2 mb-2">
                  <CalendarIcon className="h-4 w-4 text-muted-foreground" />
                  <h3 className="text-sm font-medium">{formatDate(date)}</h3>
                </div>
                <div className="space-y-2">
                  {tasksForDate.map((task) => (
                    <div
                      key={task.id}
                      className={`p-3 border rounded-md flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 ${task.completed ? "bg-muted/50" : ""}`}
                    >
                      <div className="flex items-center gap-2 w-full sm:w-auto">
                        <Checkbox
                          checked={task.completed}
                          onCheckedChange={() => onTaskComplete(task.id)}
                          id={`task-${task.id}`}
                        />
                        <div className="flex flex-col">
                          <label
                            htmlFor={`task-${task.id}`}
                            className={`font-medium ${task.completed ? "line-through text-muted-foreground" : ""}`}
                          >
                            {task.subject}
                          </label>
                          <div className="flex items-center gap-2 text-xs text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              {formatTime(task.estimatedTime)}
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 w-full sm:w-auto justify-between sm:justify-end">
                        <Badge variant={getPriorityColor(task.priority) as any}>
                          {task.priority}
                        </Badge>
                        <div className="flex items-center gap-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => onTaskEdit(task)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button variant="ghost" size="sm">
                                <Trash2 className="h-4 w-4 text-destructive" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Delete Task</AlertDialogTitle>
                                <AlertDialogDescription>
                                  Are you sure you want to delete this task?
                                  This action cannot be undone.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction
                                  onClick={() => onTaskDelete(task.id)}
                                >
                                  Delete
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })
        ) : (
          <div className="py-8 text-center">
            <p className="text-muted-foreground">
              No tasks found. Try adjusting your filters or create a new task.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default TaskList;
