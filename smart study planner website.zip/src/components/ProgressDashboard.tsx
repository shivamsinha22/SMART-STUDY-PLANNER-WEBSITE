import React, { useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  BarChart,
  LineChart,
  PieChart,
  Activity,
  Calendar,
  Clock,
} from "lucide-react";

interface Subject {
  id: string;
  name: string;
  color: string;
  completionRate: number;
  plannedHours: number;
  actualHours: number;
}

interface Task {
  id: string;
  subject: string;
  title: string;
  dueDate: string;
  isCompleted: boolean;
  priority: "low" | "medium" | "high";
}

const ProgressDashboard = ({
  subjects = defaultSubjects,
  tasks = defaultTasks,
}: {
  subjects?: Subject[];
  tasks?: Task[];
}) => {
  const [timeRange, setTimeRange] = useState<string>("week");
  const [selectedSubject, setSelectedSubject] = useState<string>("all");

  // Calculate overall completion rate
  const overallCompletionRate =
    subjects.reduce((acc, subject) => acc + subject.completionRate, 0) /
    subjects.length;

  // Calculate time efficiency (actual vs planned)
  const totalPlannedHours = subjects.reduce(
    (acc, subject) => acc + subject.plannedHours,
    0,
  );
  const totalActualHours = subjects.reduce(
    (acc, subject) => acc + subject.actualHours,
    0,
  );
  const timeEfficiency =
    totalPlannedHours > 0 ? (totalActualHours / totalPlannedHours) * 100 : 0;

  // Filter tasks by completion status
  const completedTasks = tasks.filter((task) => task.isCompleted).length;
  const pendingTasks = tasks.length - completedTasks;
  const taskCompletionRate =
    tasks.length > 0 ? (completedTasks / tasks.length) * 100 : 0;

  // Get upcoming deadlines (next 7 days)
  const today = new Date();
  const nextWeek = new Date(today);
  nextWeek.setDate(today.getDate() + 7);

  const upcomingDeadlines = tasks
    .filter((task) => {
      const dueDate = new Date(task.dueDate);
      return dueDate >= today && dueDate <= nextWeek && !task.isCompleted;
    })
    .sort(
      (a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime(),
    );

  return (
    <div className="w-full h-full bg-background p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold">Study Progress Dashboard</h2>
        <div className="flex items-center gap-4">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select time range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="day">Today</SelectItem>
              <SelectItem value="week">This Week</SelectItem>
              <SelectItem value="month">This Month</SelectItem>
              <SelectItem value="semester">This Semester</SelectItem>
            </SelectContent>
          </Select>

          <Select value={selectedSubject} onValueChange={setSelectedSubject}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filter by subject" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Subjects</SelectItem>
              {subjects.map((subject) => (
                <SelectItem key={subject.id} value={subject.id}>
                  {subject.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">
              Overall Completion
            </CardTitle>
            <PieChart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {Math.round(overallCompletionRate)}%
            </div>
            <Progress className="h-2 mt-2" value={overallCompletionRate} />
            <p className="text-xs text-muted-foreground mt-2">
              Average across all subjects
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">
              Time Efficiency
            </CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {Math.round(timeEfficiency)}%
            </div>
            <Progress
              className="h-2 mt-2"
              value={timeEfficiency > 100 ? 100 : timeEfficiency}
            />
            <p className="text-xs text-muted-foreground mt-2">
              {totalActualHours} hrs spent / {totalPlannedHours} hrs planned
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">
              Task Completion
            </CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {Math.round(taskCompletionRate)}%
            </div>
            <Progress className="h-2 mt-2" value={taskCompletionRate} />
            <p className="text-xs text-muted-foreground mt-2">
              {completedTasks} completed / {pendingTasks} pending
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">
              Upcoming Deadlines
            </CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{upcomingDeadlines.length}</div>
            <p className="text-xs text-muted-foreground mt-2">
              {upcomingDeadlines.length > 0
                ? `Next: ${upcomingDeadlines[0].title} (${formatDate(upcomingDeadlines[0].dueDate)})`
                : "No upcoming deadlines"}
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="subjects" className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="subjects">By Subject</TabsTrigger>
          <TabsTrigger value="timeline">Timeline</TabsTrigger>
          <TabsTrigger value="priorities">By Priority</TabsTrigger>
        </TabsList>

        <TabsContent value="subjects" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Subject Progress</CardTitle>
              <CardDescription>
                Track your progress across different subjects
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {subjects.map((subject) => (
                  <div key={subject.id} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div
                          className="w-3 h-3 rounded-full"
                          style={{ backgroundColor: subject.color }}
                        />
                        <span className="font-medium">{subject.name}</span>
                      </div>
                      <span className="text-sm">{subject.completionRate}%</span>
                    </div>
                    <Progress value={subject.completionRate} className="h-2" />
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>{subject.actualHours} hrs spent</span>
                      <span>{subject.plannedHours} hrs planned</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="timeline" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Study Timeline</CardTitle>
              <CardDescription>Your study hours over time</CardDescription>
            </CardHeader>
            <CardContent className="h-[300px] flex items-center justify-center">
              <div className="text-center text-muted-foreground">
                <LineChart className="h-16 w-16 mx-auto mb-2" />
                <p>Timeline visualization would appear here</p>
                <p className="text-sm">Showing data for: {timeRange}</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="priorities" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Tasks by Priority</CardTitle>
              <CardDescription>
                Distribution of tasks by priority level
              </CardDescription>
            </CardHeader>
            <CardContent className="h-[300px] flex items-center justify-center">
              <div className="text-center text-muted-foreground">
                <BarChart className="h-16 w-16 mx-auto mb-2" />
                <p>Priority distribution chart would appear here</p>
                <p className="text-sm">
                  High: {tasks.filter((t) => t.priority === "high").length} |
                  Medium: {tasks.filter((t) => t.priority === "medium").length}{" "}
                  | Low: {tasks.filter((t) => t.priority === "low").length}
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

// Helper function to format dates
const formatDate = (dateString: string): string => {
  const date = new Date(dateString);
  return date.toLocaleDateString("en-US", { month: "short", day: "numeric" });
};

// Default mock data
const defaultSubjects: Subject[] = [
  {
    id: "1",
    name: "Mathematics",
    color: "#FF5733",
    completionRate: 75,
    plannedHours: 20,
    actualHours: 15,
  },
  {
    id: "2",
    name: "Physics",
    color: "#33A1FF",
    completionRate: 60,
    plannedHours: 15,
    actualHours: 10,
  },
  {
    id: "3",
    name: "Computer Science",
    color: "#33FF57",
    completionRate: 85,
    plannedHours: 25,
    actualHours: 28,
  },
  {
    id: "4",
    name: "Literature",
    color: "#F033FF",
    completionRate: 40,
    plannedHours: 10,
    actualHours: 5,
  },
];

const defaultTasks: Task[] = [
  {
    id: "1",
    subject: "1",
    title: "Calculus Assignment",
    dueDate: "2023-06-15",
    isCompleted: true,
    priority: "high",
  },
  {
    id: "2",
    subject: "2",
    title: "Physics Lab Report",
    dueDate: "2023-06-18",
    isCompleted: false,
    priority: "medium",
  },
  {
    id: "3",
    subject: "3",
    title: "Programming Project",
    dueDate: "2023-06-20",
    isCompleted: false,
    priority: "high",
  },
  {
    id: "4",
    subject: "4",
    title: "Book Analysis",
    dueDate: "2023-06-25",
    isCompleted: false,
    priority: "low",
  },
  {
    id: "5",
    subject: "1",
    title: "Statistics Quiz Prep",
    dueDate: "2023-06-16",
    isCompleted: true,
    priority: "medium",
  },
  {
    id: "6",
    subject: "3",
    title: "Algorithm Study",
    dueDate: "2023-06-19",
    isCompleted: false,
    priority: "medium",
  },
];

export default ProgressDashboard;
