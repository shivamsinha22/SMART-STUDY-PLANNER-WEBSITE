import React, { useState } from "react";
import Calendar from "./Calendar";
import TaskForm from "./TaskForm";
import TaskList from "./TaskList";
import ProgressDashboard from "./ProgressDashboard";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  PlusCircle,
  Calendar as CalendarIcon,
  ListTodo,
  BarChart3,
  Settings,
} from "lucide-react";

const Home = () => {
  const [activeTab, setActiveTab] = useState("calendar");
  const [showTaskForm, setShowTaskForm] = useState(false);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-primary">
            Smart Study Planner
          </h1>
          <div className="flex items-center gap-4">
            <Button variant="outline" size="sm">
              <Settings className="h-4 w-4 mr-2" />
              Settings
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-6">
        <div className="flex flex-col md:flex-row gap-6">
          {/* Sidebar */}
          <aside className="w-full md:w-64 shrink-0">
            <Card>
              <CardContent className="p-4">
                <Button
                  className="w-full mb-4"
                  onClick={() => setShowTaskForm(true)}
                >
                  <PlusCircle className="h-4 w-4 mr-2" />
                  Add New Task
                </Button>

                <nav className="space-y-2">
                  <Button
                    variant={activeTab === "calendar" ? "default" : "ghost"}
                    className="w-full justify-start"
                    onClick={() => setActiveTab("calendar")}
                  >
                    <CalendarIcon className="h-4 w-4 mr-2" />
                    Calendar
                  </Button>
                  <Button
                    variant={activeTab === "tasks" ? "default" : "ghost"}
                    className="w-full justify-start"
                    onClick={() => setActiveTab("tasks")}
                  >
                    <ListTodo className="h-4 w-4 mr-2" />
                    Tasks
                  </Button>
                  <Button
                    variant={activeTab === "progress" ? "default" : "ghost"}
                    className="w-full justify-start"
                    onClick={() => setActiveTab("progress")}
                  >
                    <BarChart3 className="h-4 w-4 mr-2" />
                    Progress
                  </Button>
                </nav>
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <Card className="mt-4">
              <CardContent className="p-4">
                <h3 className="text-sm font-medium mb-2">Quick Stats</h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">
                      Tasks Due Today
                    </span>
                    <span className="font-medium">3</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">
                      Completed Tasks
                    </span>
                    <span className="font-medium">12</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">
                      Study Hours
                    </span>
                    <span className="font-medium">24.5</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </aside>

          {/* Main Content Area */}
          <main className="flex-1">
            <Tabs
              value={activeTab}
              onValueChange={setActiveTab}
              className="w-full"
            >
              <TabsList className="mb-4">
                <TabsTrigger value="calendar">Calendar</TabsTrigger>
                <TabsTrigger value="tasks">Tasks</TabsTrigger>
                <TabsTrigger value="progress">Progress</TabsTrigger>
              </TabsList>

              <TabsContent value="calendar" className="space-y-4">
                <Calendar />
              </TabsContent>

              <TabsContent value="tasks" className="space-y-4">
                <TaskList />
              </TabsContent>

              <TabsContent value="progress" className="space-y-4">
                <ProgressDashboard />
              </TabsContent>
            </Tabs>
          </main>
        </div>
      </div>

      {/* Task Form Modal */}
      {showTaskForm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-background rounded-lg w-full max-w-md p-4">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">Add New Task</h2>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowTaskForm(false)}
              >
                ✕
              </Button>
            </div>
            <TaskForm onClose={() => setShowTaskForm(false)} />
          </div>
        </div>
      )}
    </div>
  );
};

export default Home;
