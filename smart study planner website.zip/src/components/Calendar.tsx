import React, { useState } from "react";
import { Calendar as CalendarUI } from "@/components/ui/calendar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import {
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import {
  format,
  addMonths,
  subMonths,
  startOfWeek,
  endOfWeek,
  eachDayOfInterval,
  isSameDay,
  isValid,
} from "date-fns";

interface Task {
  id: string;
  subject: string;
  priority: "low" | "medium" | "high";
  estimatedTime: number;
  dueDate: Date;
  completed: boolean;
}

interface CalendarProps {
  tasks?: Task[];
  onDateSelect?: (date: Date) => void;
}

const Calendar = ({ tasks = [], onDateSelect = () => {} }: CalendarProps) => {
  const [currentDate, setCurrentDate] = useState<Date>(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [view, setView] = useState<"month" | "week">("month");

  // Sample tasks for demonstration
  const sampleTasks: Task[] = [
    {
      id: "1",
      subject: "Math Study",
      priority: "high",
      estimatedTime: 2,
      dueDate: new Date(),
      completed: false,
    },
    {
      id: "2",
      subject: "History Essay",
      priority: "medium",
      estimatedTime: 3,
      dueDate: new Date(Date.now() + 86400000), // Tomorrow
      completed: false,
    },
    {
      id: "3",
      subject: "Science Lab",
      priority: "low",
      estimatedTime: 1,
      dueDate: new Date(Date.now() + 172800000), // Day after tomorrow
      completed: false,
    },
  ];

  const allTasks = tasks.length > 0 ? tasks : sampleTasks;

  // Get tasks for a specific date
  const getTasksForDate = (date: Date) => {
    if (!isValid(date)) return [];
    return allTasks.filter((task) => {
      const taskDate = new Date(task.dueDate);
      return isValid(taskDate) && isSameDay(taskDate, date);
    });
  };

  // Priority color mapping
  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-500";
      case "medium":
        return "bg-yellow-500";
      case "low":
        return "bg-green-500";
      default:
        return "bg-blue-500";
    }
  };

  // Navigation handlers
  const goToPreviousPeriod = () => {
    setCurrentDate(subMonths(currentDate, 1));
  };

  const goToNextPeriod = () => {
    setCurrentDate(addMonths(currentDate, 1));
  };

  const goToToday = () => {
    const today = new Date();
    setCurrentDate(today);
    setSelectedDate(today);
  };

  // Week view data
  const weekStart = startOfWeek(currentDate);
  const weekEnd = endOfWeek(currentDate);
  const weekDays = eachDayOfInterval({ start: weekStart, end: weekEnd });

  const handleDateSelect = (date: Date | undefined) => {
    if (date && isValid(date)) {
      setSelectedDate(date);
      setCurrentDate(date);
      onDateSelect(date);
    }
  };

  return (
    <Card className="w-full bg-white shadow-md">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl font-bold">Study Schedule</CardTitle>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm" onClick={goToPreviousPeriod}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="sm" onClick={goToToday}>
              Today
            </Button>
            <Button variant="outline" size="sm" onClick={goToNextPeriod}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
        <div className="flex items-center justify-between mt-2">
          <div className="text-lg font-medium">
            {view === "month"
              ? format(currentDate, "MMMM yyyy")
              : `${format(weekStart, "MMM d")} - ${format(weekEnd, "MMM d, yyyy")}`}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs
          defaultValue="month"
          value={view}
          onValueChange={(value) => setView(value as "month" | "week")}
        >
          <TabsList className="mb-4">
            <TabsTrigger value="month">Month</TabsTrigger>
            <TabsTrigger value="week">Week</TabsTrigger>
          </TabsList>
          
          <TabsContent value="month" className="mt-0">
            <div className="space-y-4">
              <CalendarUI
                mode="single"
                selected={selectedDate}
                onSelect={handleDateSelect}
                className="rounded-md border"
                month={currentDate}
                onMonthChange={setCurrentDate}
              />
              
              {/* Task indicators for selected date */}
              {selectedDate && (
                <div className="mt-4 p-4 border rounded-md bg-muted/20">
                  <h4 className="font-medium mb-2">
                    Tasks for {format(selectedDate, "MMMM d, yyyy")}
                  </h4>
                  <div className="space-y-2">
                    {getTasksForDate(selectedDate).length > 0 ? (
                      getTasksForDate(selectedDate).map((task) => (
                        <div
                          key={task.id}
                          className={`p-2 rounded-sm ${getPriorityColor(task.priority)} text-white text-sm`}
                        >
                          <div className="font-medium">{task.subject}</div>
                          <div className="text-xs opacity-90">
                            {task.estimatedTime}h • {task.priority} priority
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="text-sm text-muted-foreground">
                        No tasks scheduled for this date
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </TabsContent>
          
          <TabsContent value="week" className="mt-0">
            <div className="grid grid-cols-7 gap-1">
              {weekDays.map((day) => {
                const tasksForDay = getTasksForDate(day);
                const isToday = isSameDay(day, new Date());
                const isSelected = selectedDate && isSameDay(day, selectedDate);
                
                return (
                  <div
                    key={day.toString()}
                    className={`border rounded-md p-2 min-h-[120px] cursor-pointer hover:bg-muted/50 ${
                      isToday ? "bg-blue-50 border-blue-200" : ""
                    } ${isSelected ? "bg-blue-100 border-blue-300" : ""}`}
                    onClick={() => handleDateSelect(day)}
                  >
                    <div className="text-center font-medium mb-2">
                      <div className="text-xs text-muted-foreground">
                        {format(day, "EEE")}
                      </div>
                      <div className={`text-lg ${isToday ? "font-bold text-blue-600" : ""}`}>
                        {format(day, "d")}
                      </div>
                    </div>
                    <div className="space-y-1">
                      {tasksForDay.length > 0 ? (
                        <>
                          {tasksForDay.slice(0, 2).map((task) => (
                            <div
                              key={task.id}
                              className={`text-xs p-1 rounded-sm ${getPriorityColor(task.priority)} text-white truncate`}
                            >
                              {task.subject}
                            </div>
                          ))}
                          {tasksForDay.length > 2 && (
                            <Badge
                              variant="outline"
                              className="w-full justify-center text-xs"
                            >
                              +{tasksForDay.length - 2} more
                            </Badge>
                          )}
                        </>
                      ) : (
                        <div className="text-xs text-muted-foreground text-center mt-4">
                          No tasks
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default Calendar;